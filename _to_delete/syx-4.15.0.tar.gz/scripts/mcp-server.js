#!/usr/bin/env node
/**
 * SYX — Servidor MCP sobre la capa de contratos
 * ─────────────────────────────────────────────
 * Expone SYX por Model Context Protocol para que un agente pueda CONSULTARLO en
 * vez de ingerirlo. Es el paso 1.1 del plan agentic, y la frontera exacta entre
 * «legible por máquina» y «consultable»: hoy responder «¿de qué color es el
 * botón primario?» obliga a leer 274 KB de tokens.json más 317 KB de
 * token-contract.json y resolver la cascada a mano. Aquí es una llamada.
 *
 * SIN DEPENDENCIAS
 * MCP sobre stdio es JSON-RPC 2.0 con las líneas delimitadas por saltos: cabe
 * en cien líneas y no justifica arrastrar un SDK a un proyecto cuyo argumento
 * principal es no arrastrar nada. Se implementan los tres métodos que necesita
 * un cliente para funcionar: initialize, tools/list y tools/call.
 *
 * DE DÓNDE SALEN LAS RESPUESTAS
 * De los artefactos de la fase P0, que por primera vez son ciertos:
 *   · contracts/resolved-tokens.json  valores por tema y modo (paso 0.2)
 *   · component-registry.json         clases y tokens reales  (paso 0.1)
 *   · css/styles-theme-*.css          para la cadena de alias, bajo demanda
 *   · scripts/lib/rules.js            R01–R04, las mismas que el validador
 *
 * Registro en un cliente MCP:
 *   { "command": "node", "args": ["scripts/mcp-server.js"], "cwd": "<repo>" }
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { parseBlocks, declaredFor, cadenaDeAlias, canonico } = require('./lib/css-tokens');
const { revisar, tokensInexistentes, DESCRIPCIONES } = require('./lib/rules');

const ROOT = path.join(__dirname, '..');
const SNAP = path.join(ROOT, 'contracts', 'resolved-tokens.json');
const REGISTRO = path.join(ROOT, 'component-registry.json');
const TOKENS = path.join(ROOT, 'tokens.json');

// ─── Datos ───────────────────────────────────────────────────────────────────
// Se cargan una vez y se quedan en memoria; el CSS de cada tema solo se analiza
// si alguien pide una cadena de alias, que es la única consulta que lo necesita.

let snap = null;
let registro = null;
let conocidos = null;
const declaracionesCache = new Map();

function cargar() {
  if (!fs.existsSync(SNAP)) {
    throw new Error('Falta contracts/resolved-tokens.json. Ejecuta: npm run build:tokens');
  }
  if (!fs.existsSync(REGISTRO)) {
    throw new Error('Falta component-registry.json. Ejecuta: npm run build:registry');
  }
  snap = JSON.parse(fs.readFileSync(SNAP, 'utf8'));
  registro = JSON.parse(fs.readFileSync(REGISTRO, 'utf8'));
  const t = JSON.parse(fs.readFileSync(TOKENS, 'utf8'));
  conocidos = new Set();
  for (const [k, v] of Object.entries(t)) {
    if (k === '_meta' || typeof v !== 'object') continue;
    for (const nombre of Object.keys(v)) conocidos.add(nombre);
  }
}

const componentes = () =>
  ['atoms', 'molecules', 'organisms'].flatMap((g) => registro[g] || []);

function efectivo(tema, modo) {
  const t = snap.themes[tema];
  if (!t) throw new Error(`Tema desconocido: ${tema}. Disponibles: ${snap._meta.themes.join(', ')}`);
  return { ...snap.base, ...t.light, ...(modo === 'dark' ? t.dark : {}) };
}

const resolverAsset = (v) =>
  typeof v === 'string' && v.startsWith('@asset/') ? snap.assets[v.slice(7)] : v;

function declaracionesDe(tema, modo) {
  const clave = `${tema}/${modo}`;
  if (declaracionesCache.has(clave)) return declaracionesCache.get(clave);
  const f = path.join(ROOT, 'css', `styles-theme-${tema}.css`);
  if (!fs.existsSync(f)) return null;
  const d = declaredFor(parseBlocks(fs.readFileSync(f, 'utf8')), modo);
  declaracionesCache.set(clave, d);
  return d;
}

// El índice inverso NO se versiona a propósito: se deriva del snapshot en una
// pasada y guardarlo duplicaba el fichero. Aquí se construye al vuelo.
const invCache = new Map();
function indiceInverso(tema, modo) {
  const clave = `${tema}/${modo}`;
  if (invCache.has(clave)) return invCache.get(clave);
  const inv = new Map();
  for (const [k, v] of Object.entries(efectivo(tema, modo))) {
    const val = canonico(resolverAsset(v) || '');
    if (!val) continue;
    if (!inv.has(val)) inv.set(val, []);
    inv.get(val).push(k);
  }
  invCache.set(clave, inv);
  return inv;
}

// ─── Herramientas ────────────────────────────────────────────────────────────

const HERRAMIENTAS = [
  {
    name: 'list_themes',
    description: 'Los temas disponibles y sus modos. Empieza por aquí si no sabes qué nombre pasar a las demás herramientas.',
    inputSchema: { type: 'object', properties: {} },
    run: () => ({
      themes: snap._meta.themes,
      modes: snap._meta.modes,
      default: 'syx-sketch',
      tokensPorTema: Object.keys(snap.base).length + Object.keys(snap.themes[snap._meta.themes[0]].light).length,
    }),
  },

  {
    name: 'get_token',
    description: 'El valor REAL de un token en un tema y un modo, con la cadena de alias que lo produce. Responde a "¿de qué color es esto aquí?" sin tener que resolver la cascada.',
    inputSchema: {
      type: 'object',
      properties: {
        token: { type: 'string', description: 'Nombre completo, p. ej. --component-button-primary-filled-bg' },
        theme: { type: 'string', description: 'Por defecto syx-sketch' },
        mode: { type: 'string', enum: ['light', 'dark'], description: 'Por defecto light' },
      },
      required: ['token'],
    },
    run: ({ token, theme = 'syx-sketch', mode = 'light' }) => {
      const mapa = efectivo(theme, mode);
      if (!(token in mapa)) {
        const cerca = Object.keys(mapa)
          .filter((k) => k.includes(token.replace(/^--/, '').split('-')[0]))
          .slice(0, 8);
        return { encontrado: false, token, sugerencias: cerca };
      }
      const roto = snap.themes[theme].unresolved;
      const porQueVacio = (roto[mode] || roto)[token];
      const decl = declaracionesDe(theme, mode);
      return {
        encontrado: true,
        token,
        theme,
        mode,
        value: resolverAsset(mapa[token]),
        esExpresion: snap.themes[theme].expressions.includes(token),
        sinValor: porQueVacio || null,
        cadena: decl ? cadenaDeAlias(decl, token) : null,
      };
    },
  },

  {
    name: 'find_token_by_value',
    description: 'Qué token o tokens valen un color o medida concretos. Es la consulta que evita escribir el valor a pelo: antes de poner un #1e3aff en una hoja, preguntar cuál es su token.',
    inputSchema: {
      type: 'object',
      properties: {
        value: { type: 'string', description: 'p. ej. oklch(0.498 0.282 266.24) o 1.5rem' },
        theme: { type: 'string' },
        mode: { type: 'string', enum: ['light', 'dark'] },
      },
      required: ['value'],
    },
    run: ({ value, theme = 'syx-sketch', mode = 'light' }) => {
      const inv = indiceInverso(theme, mode);
      const buscado = canonico(value);
      const exactos = inv.get(buscado) || [];
      // Sin coincidencia exacta se ofrecen los que CONTIENEN el texto, que es
      // lo que hace útil buscar "266.24" o "blue" sin saber la sintaxis exacta.
      const parciales = exactos.length ? [] : [...inv.entries()]
        .filter(([v]) => v.includes(buscado))
        .slice(0, 10)
        .map(([v, ks]) => ({ value: v, tokens: ks }));
      return { value: buscado, theme, mode, exactos, parciales };
    },
  },

  {
    name: 'list_components',
    description: 'El inventario de componentes con su capa y sus clases base. Generado desde el código y contrastado contra el CSS compilado: lo que sale de aquí existe.',
    inputSchema: {
      type: 'object',
      properties: { layer: { type: 'string', enum: ['atom', 'molecule', 'organism'] } },
    },
    run: ({ layer } = {}) => ({
      total: componentes().length,
      components: componentes()
        .filter((c) => !layer || c.layer === layer)
        .map((c) => ({ name: c.name, layer: c.layer, classes: c.classes, file: c.file })),
    }),
  },

  {
    name: 'get_component',
    description: 'Todo lo de un componente: clases, modificadores, elementos, estados, de qué se compone y qué tokens consume. Todos verificados contra el CSS compilado.',
    inputSchema: {
      type: 'object',
      properties: { name: { type: 'string', description: 'p. ej. btn, feature-card, site-header' } },
      required: ['name'],
    },
    run: ({ name }) => {
      const c = componentes().find((x) => x.name === name || x.classes.includes(name) || x.classes.includes(name.replace(/^\./, '')));
      if (!c) {
        return {
          encontrado: false,
          name,
          sugerencias: componentes().map((x) => x.name).filter((n) => n.includes(name) || name.includes(n)).slice(0, 8),
        };
      }
      return { encontrado: true, ...c };
    },
  },

  {
    name: 'validate_snippet',
    description: 'Pasa las reglas de contrato R01–R04 sobre un fragmento de SCSS ANTES de escribirlo, y avisa de los tokens que usa y no existen. Las mismas reglas que ejecuta npm run validate.',
    inputSchema: {
      type: 'object',
      properties: {
        code: { type: 'string', description: 'El SCSS a revisar' },
        path: { type: 'string', description: 'Dónde va a vivir. Importa: las excepciones dependen de la ruta. Por defecto scss/atoms/_nuevo.scss, que es el contexto más estricto.' },
      },
      required: ['code'],
    },
    run: ({ code, path: rel = 'scss/atoms/_nuevo.scss' }) => {
      const v = revisar(rel, code);
      const fuera = tokensInexistentes(code, conocidos);
      const rotos = fuera.filter((t) => !t.conFallback);
      const total = Object.values(v).reduce((a, x) => a + x.length, 0);
      return {
        path: rel,
        conforme: total === 0 && rotos.length === 0,
        violaciones: Object.fromEntries(
          Object.entries(v).filter(([, x]) => x.length)
            .map(([k, x]) => [k, { regla: DESCRIPCIONES[k], casos: x }])
        ),
        tokensInexistentes: fuera,
        nota: rotos.length
          ? 'Los tokens sin fallback y sin declarar dejan la propiedad sin valor.'
          : undefined,
      };
    },
  },
];

// ─── JSON-RPC sobre stdio ────────────────────────────────────────────────────

function responder(id, result) {
  process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, result }) + '\n');
}
function fallar(id, code, message) {
  process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, error: { code, message } }) + '\n');
}

function manejar(msg) {
  const { id, method, params } = msg;
  // Las notificaciones no llevan id y no se responden.
  if (id === undefined) return;

  if (method === 'initialize') {
    return responder(id, {
      protocolVersion: '2024-11-05',
      capabilities: { tools: {} },
      serverInfo: { name: 'syx', version: require(path.join(ROOT, 'package.json')).version },
    });
  }

  if (method === 'tools/list') {
    return responder(id, {
      tools: HERRAMIENTAS.map(({ name, description, inputSchema }) => ({ name, description, inputSchema })),
    });
  }

  if (method === 'tools/call') {
    const h = HERRAMIENTAS.find((x) => x.name === params?.name);
    if (!h) return fallar(id, -32601, `Herramienta desconocida: ${params?.name}`);
    try {
      const salida = h.run(params.arguments || {});
      return responder(id, { content: [{ type: 'text', text: JSON.stringify(salida, null, 2) }] });
    } catch (e) {
      // El error va como resultado y no como fallo de protocolo: así el agente
      // lo lee y puede corregir, en vez de recibir una excepción opaca.
      return responder(id, {
        content: [{ type: 'text', text: JSON.stringify({ error: e.message }, null, 2) }],
        isError: true,
      });
    }
  }

  fallar(id, -32601, `Método no soportado: ${method}`);
}

function main() {
  cargar();
  let buffer = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (trozo) => {
    buffer += trozo;
    let corte;
    while ((corte = buffer.indexOf('\n')) !== -1) {
      const linea = buffer.slice(0, corte).trim();
      buffer = buffer.slice(corte + 1);
      if (!linea) continue;
      try {
        manejar(JSON.parse(linea));
      } catch (e) {
        fallar(null, -32700, 'JSON mal formado: ' + e.message);
      }
    }
  });
  process.stdin.on('end', () => process.exit(0));
}

main();
